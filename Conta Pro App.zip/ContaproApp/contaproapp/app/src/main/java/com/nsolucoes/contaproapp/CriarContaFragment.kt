package com.nsolucoes.contaproapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.generation.contaproapp.dataUser.Usuario
import com.nsolucoes.contaproapp.databinding.FragmentCriarContaBinding

class CriarContaFragment : Fragment() {

    private lateinit var binding: FragmentCriarContaBinding
    private lateinit var mainViewModel: MainViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCriarContaBinding.inflate(layoutInflater, container, false)

        mainViewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        binding.buttonConcluir.setOnClickListener{
           inserirBanco()
        }
        // Inflate the layout for this fragment
        return binding.root
    }

    fun verificarCampos(
        nomeCompleto: String, dataNascimento: String,
        cpf: String, cep: String, estado: String, cidade: String, bairro: String, complemento: String,
        email: String, senha: String, confirmarSenha: String): Boolean{

        //verificar se dados estão vazios
        return !(nomeCompleto == "" || dataNascimento == "" || cpf == "" ||
                cep == "" || estado == "" || cidade == "" ||
                bairro == "" || complemento == "" || email == "" ||
                senha == "" || confirmarSenha == "")
    }

    fun inserirBanco(){
        val nomeCompleto = binding.editTextNomeCompleto.text.toString()
        val dataNascimento = binding.editTextNascimento.text.toString()
        val cpf = binding.editTextCPF.text.toString()
        val cep = binding.editTextNumberCep.text.toString()
        val estado = binding.editTextEstado.text.toString()
        val cidade = binding.editTextCidade.text.toString()
        //val logradouro = binding.editTextLogradouro.text.toString()
        //val numero = binding.editTextNumber.text.toString()
        val bairro = binding.editTextBairro.text.toString()
        val complemento = binding.editTextComplemento.text.toString()
        val email = binding.editTextEmail.text.toString()
        val senha = binding.editTextSenhaCad.text.toString()
        val confirmarSenha = binding.editTextConfirmaSenha.text.toString()

        if (verificarCampos(nomeCompleto, dataNascimento, cpf, cep, estado, cidade, bairro, complemento, email, senha, confirmarSenha)){

            val user = Usuario(0, nomeCompleto, dataNascimento, cpf, cep, estado, cidade,
                 bairro, complemento, email, senha, confirmarSenha)
            mainViewModel.addUser(user)
            Toast.makeText(context, "Usuário cadastrado", Toast.LENGTH_SHORT).show()

            // realizar a navegação entre as páginas após a validação dos dados
            findNavController().navigate(R.id.action_criarContaFragment2_to_loginFragment)
        }else{
            Toast.makeText(context, "Dados incompletos", Toast.LENGTH_SHORT).show()
        }
    }
}