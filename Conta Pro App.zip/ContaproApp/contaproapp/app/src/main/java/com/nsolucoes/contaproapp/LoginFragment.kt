package com.nsolucoes.contaproapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.generation.contaproapp.dataUser.Usuario
import com.nsolucoes.contaproapp.adapter.UserAdapter
import com.nsolucoes.contaproapp.databinding.FragmentLoginBinding

class LoginFragment : Fragment() {

    private lateinit var binding: FragmentLoginBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentLoginBinding.inflate(layoutInflater, container, false)

        //mainViewModel =

        binding.buttonEntrar.setOnClickListener {
            entrar()
        }

        binding.buttonContaCriada.setOnClickListener {
            findNavController().navigate(R.id.action_loginFragment_to_criarContaFragment2)
        }

        return binding.root
    }


    fun validarCampos(cpf: String, senha: String): Boolean {
        //verificar se dados estão vazios
        return !(cpf == "" || senha == "")
    }

    fun entrar() {
        val cpfLogin = binding.editTextUsuario.text.toString()
        val senhaLogin = binding.editTextSenha.text.toString()

        if (validarCampos(cpfLogin, senhaLogin)) {
            //val user = Usuario()
            Toast.makeText(context, "Bem vindo!", Toast.LENGTH_SHORT).show()

            // realizar a navegação entre as páginas após a validação dos dados
            findNavController().navigate(R.id.action_loginFragment_to_listDadosFragment)
        }
    }
}